package org.ihtsdo.arena;

import java.awt.GridLayout;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;
import java.util.UUID;
import java.util.logging.Level;

import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.TransformerFactory;

import org.dwfa.ace.api.I_GetConceptData;
import org.dwfa.ace.log.AceLog;
import org.ihtsdo.workflow.WorkflowHistoryJavaBean;
import org.ihtsdo.workflow.refset.history.WorkflowHistoryRefset;
import org.ihtsdo.workflow.refset.utilities.WorkflowHelper;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ArenaWfHxPanel extends JPanel {
	
	private class Workflow {
		private String id;
		private String action;
		private String state;
		private String modeler;
		private String time;
		
		public String getId() {
			return id;
		}

		public String getAction() {
			return action;
		}

		public String getState() {
			return state;
		}

		public String getModeler() {
			return modeler;
		}

		public String getTime() {
			return time;
		}

		public void setId(String uuid) {
			id = uuid;
		}
		
		public void setAction(String act) {
			action = act;
		}
		
		public void setState(String st) {
			state = st;
		}
		
		public void setModeler(String mod) {
			modeler = mod;
		}

		public void setTime(String t) {
			time = t;
		}
	}
	
	public class WfHxXmlHandler extends DefaultHandler{
		 
	    private String tempVal;
		private Workflow tempWorkflow;
		
		public void startDocument() throws SAXException {
	        allWorkflows = new ArrayList<Workflow>();
	    }

	    public void endDocument() throws SAXException {
	        
	    }

	    public void startElement(String uri, String localName,
	    						 String qName, Attributes attributes)
	    	throws SAXException {
	    	tempWorkflow = new Workflow();
	    }

	    public void endElement(String uri, String localName, String qName)
	    	throws SAXException {
	    	if(qName.equalsIgnoreCase("workflow")) {
				//add it to the list
				allWorkflows.add(tempWorkflow);	    
	    	} else if (qName.equalsIgnoreCase("Id")) {
				tempWorkflow.setId(tempVal);
	    	} else if (qName.equalsIgnoreCase("Action")) {
				tempWorkflow.setAction(tempVal);
			} else if (qName.equalsIgnoreCase("State")) {
				tempWorkflow.setState(tempVal);
			} else if (qName.equalsIgnoreCase("Modeler")) {
				tempWorkflow.setModeler(tempVal);
			} else if (qName.equalsIgnoreCase("Time")) {
				tempWorkflow.setTime(tempVal);
			}
	    }

	    public void characters(char ch[], int start, int length)
	    throws SAXException {
	        tempVal = new String(ch, start, length);
	    }
	}

	private JEditorPane htmlPane = new JEditorPane();
	private DefaultHandler xmlHandler;
	private static float fontSize;
	
	private List<Workflow> allWorkflows;

	private static String currentHtml;  
	private static I_GetConceptData currentConcept = null;
	private static long latestConceptTimestamp = Long.MIN_VALUE;

	public ArenaWfHxPanel(ArenaComponentSettings settings) {
		super(new GridLayout(1,1));
		fontSize = settings.getFontSize();
		htmlPane.setContentType("text/html");
		
		htmlPane.setText(generateHtmlCode(settings.getConcept()));
		
		add(htmlPane);
	}
	
	private String generateHtmlCode(I_GetConceptData arenaConcept) {
		boolean generateNewHtml = false;
		
		if (arenaConcept != null) {
			if (currentConcept == null || !arenaConcept.getPrimUuid().equals(currentConcept.getPrimUuid())) {
				generateNewHtml = true;
				currentConcept = arenaConcept;
			} 

			try {
				WorkflowHistoryJavaBean latestBean = WorkflowHelper.getLatestWfHxJavaBeanForConcept(arenaConcept);

				if (latestBean.getWorkflowTime() > latestConceptTimestamp) {
					generateNewHtml = true;
				}

				latestConceptTimestamp = latestBean.getWorkflowTime();
			} catch (Exception e) {
				AceLog.getAppLog().log(Level.WARNING, "Failure to identify latest WfHx");
			}
		}

		if (generateNewHtml) {
			currentHtml  = generateWfHxAsHtml(arenaConcept);
		}

		return currentHtml;
	}

	private String generateWfHxAsHtml(I_GetConceptData arenaConcept) {
        TransformerFactory tFactory = TransformerFactory.newInstance();
//		try {
	        TreeSet<WorkflowHistoryJavaBean> allRows = WorkflowHelper.getAllWorkflowHistory(arenaConcept);
	        String inputXml = generateXsltXml(allRows);

	        return transformerWithoutXslt(inputXml);
	        
	        
// 	        TODO: Use Xslt later
//			Transformer transformer = tFactory.newTransformer(new StreamSource("stocks.xsl"));
//        	Result res = new StreamResult(new ByteArrayOutputStream());
//        	transformer.transform(new StreamSource(inputXml), res);
//
//        	return res.toString();
//		} catch (TransformerConfigurationException e) {
//			AceLog.getAppLog().log(Level.WARNING, "Unable to configure transformation with XSLT on concept: " + arenaConcept + " with error: " + e.getMessage());
//		} catch (TransformerException e) {
//			AceLog.getAppLog().log(Level.WARNING, "Unable to perform transformation with XSLT on concept: " + arenaConcept + " with error: " + e.getMessage());
//		}
//		return "";
	}

	private void parseDocument(String inputXml) {

		//get a factory
		SAXParserFactory spf = SAXParserFactory.newInstance();
		try {

			//get a new instance of parser
			SAXParser sp = spf.newSAXParser();
			xmlHandler = new WfHxXmlHandler();
			//parse the file and also register this class for call backs
			sp.parse(new StringBufferInputStream(inputXml), xmlHandler);

		}catch(SAXException se) {
			se.printStackTrace();
		}catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		}catch (IOException ie) {
			ie.printStackTrace();
		}
	}
	private String transformerWithoutXslt(String inputXml) {
		StringBuffer retStr = new StringBuffer();
		
		// Setup XML
		retStr.append("\n<html><body>");

		// Setup Table
		retStr.append("<TABLE border=\"1\" cellpadding=\"3\" cellspacing=\"0\" width=\"300\"> 	<tbody>");
		retStr.append("<tr bgcolor=\"green\">	<th>Action</th><	th>State</th> 	<th>Modeler</th>      <th>Timestamp</th>    </tr>");
		
		parseDocument(inputXml);
		Iterator itr = allWorkflows.iterator();
		UUID currentUid = UUID.randomUUID();
		
		String currentColor = "red";
		while(itr.hasNext()) {
			Workflow currentWf = (Workflow)itr.next();
			
			if (!currentUid.toString().equalsIgnoreCase(currentWf.getId())) {
				if (currentColor.equalsIgnoreCase("red")) {
					currentColor = "yellow";
				} else {
					currentColor = "red";
				}
			} 
			
			retStr.append("<tr bgcolor=\"" + currentColor + "\">");
			retStr.append("<td>" + currentWf.getAction() + "</td>");
			retStr.append("<td>" + currentWf.getState() + "</td>");
			retStr.append("<td>" + currentWf.getModeler() + "</td>");
			retStr.append("<td>" + currentWf.getTime() + "</td>");
			retStr.append("</tr>");
		}
		
		retStr.append("\n</body></html>");
		return retStr.toString();
	}

	private String generateXsltXml(TreeSet<WorkflowHistoryJavaBean> allRows) {
		StringBuffer retStr = new StringBuffer();
		
		retStr.append("\n<workflows>");
		
		for (WorkflowHistoryJavaBean bean : allRows) {
			retStr.append("\n\t\t" + WorkflowHistoryRefset.generateXmlForXslt(bean));
		}
		retStr.append("\n</workflows>");

		return retStr.toString();
	}

	private String getHtmlCode() {
		return "<tr bgcolor=\"orange\">      <td>Accept</td>      <td>Approved</td>      <td>mvanber</td>      <td>2008-04-29 18:10:44</td>    </tr>    <tr bgcolor=\"orange\">      <td>Commit</td>      <td>Changed</td>      <td>mvanber</td>      <td>2008-04-29 18:10:43</td>    </tr>    <tr bgcolor=\"red\">      <td>Accept</td>      <td>Approved</td>      <td>mvanber</td>      <td>2008-04-28 18:10:42</td>    </tr>    <tr bgcolor=\"red\">      <td>Commit</td>      <td>Changed</td>      <td>pbrottm</td>      <td>2008-04-27 18:10:41</td>    </tr>    <tr bgcolor=\"orange\">      <td>Accept</td>      <td>Approved</td>      <td>mvanber</td>      <td>2008-04-26 18:10:43</td>    </tr>    <tr bgcolor=\"orange\">      <td>Commit</td>      <td>Changed</td>      <td>mvanber</td>      <td>2008-04-26 12:10:43</td>    </tr>  </tbody></table>";	
	}
}
